Monotech XT-IDE rev 5 ReadMe
----------------------------

8-bit ISA IDE interface + Boot ROM (two separate functions that can be used individually).

Documentation for the switches can be found on the rear silkscreen.


Credit:
-------
Design uses schematic from Glitchworks, with a few small changes to switches
PCB is made from scratch with rough IC layout based on Glitchworks for ease of routing.
https://github.com/glitchwrks/xt_ide

XT-IDE Universal BIOS
https://code.google.com/archive/p/xtideuniversalbios/